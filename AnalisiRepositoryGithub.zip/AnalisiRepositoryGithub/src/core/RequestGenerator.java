package core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RequestGenerator {
	private HttpURLConnection connection;
	private JSONObject obj = new JSONObject();
	private final static String endpoint = "https://api.github.com/search/";
	private final static String genderizeEndpoint = "https://api.genderize.io?name=";
	private final static String genderApiEndpoint = "https://gender-api.com/get?name=";
	private String target;
	private String user, githubAccessToken;

	public RequestGenerator(String in_target, String in_user, String accessTkn) {
		target = in_target;
		user = in_user;
		githubAccessToken = accessTkn;
	}
	
	public int searchByRangeOfStars(int start, int end) throws IOException, JSONException {
		int result = -1;
		if(target.equals("repositories")) {
			URL url = new URL(endpoint+target+"?q=stars%3A" + start + ".." + end);
			connection = (HttpURLConnection) url.openConnection();
		}
		if(connection.getResponseCode() >= 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine = in.readLine();
			obj = new JSONObject(inputLine);
			result = (Integer) obj.get("total_count");
			in.close();
		}
		connection.disconnect();
		return result;
	}
	
	public int searchByRangeOfForks(int start, int end) throws IOException, JSONException {
		int result = -1;
		if(target.equals("repositories")) {
			URL url = new URL(endpoint+target+"?q=stars%3A>500+forks%3A" + start + ".." + end);
			connection = (HttpURLConnection) url.openConnection();
		}
		if(connection.getResponseCode() >= 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine = in.readLine();
			obj = new JSONObject(inputLine);
			result = (Integer) obj.get("total_count");
			in.close();
		}
		connection.disconnect();
		return result;		
	}
	
	public int searchByLanguages(String language) throws IOException, JSONException {
		int result = -1;
		if(target.equals("repositories")) {
			URL url = new URL(endpoint+target+"?q=stars%3A>500+language%3A" + language);
			connection = (HttpURLConnection) url.openConnection();
		}
		if(connection.getResponseCode() >= 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine = in.readLine();
			obj = new JSONObject(inputLine);
			result = (Integer) obj.get("total_count");
			in.close();
		}
		connection.disconnect();
		return result;	
	}
	
	public List<String> searchStarsDistribution(int start, int end, int dimRange) throws InterruptedException, IOException, JSONException {
		
		List<String> arrayRepoStar = new ArrayList<String>();
		System.out.println("Request to server...");
		
		for(int i = start; i < end; i += dimRange) {
			System.out.print(i + "---" + (i+dimRange) + ": ");
			String command = "curl -u " + user + ":" + githubAccessToken + " "+ endpoint + target +"?q=stars%3A"+ i + ".." + (i+dimRange);
			
			obj = new JSONObject(this.execCommand(command));
			
			if(obj!=null && obj.get("total_count")!=null) {
				arrayRepoStar.add(String.valueOf(obj.get("total_count")));
				System.out.println(obj.get("total_count"));
			}
		}
		System.out.println("...Request completed.");
		return arrayRepoStar;
	}
	
	@SuppressWarnings("resource")
	public JSONObject obtainUserList() throws IOException, JSONException {
		JSONObject objToFile = new JSONObject();
		objToFile.put("name", "Github_toprepo_Explorer");
		objToFile.put("owner", "Antonio Giulio, Michele Delli Paoli");
		JSONArray names = new JSONArray();
		int total_page;
		String command_0 = "curl -u " + user + ":" + githubAccessToken + " " + endpoint + target + "?q=stars%3A>500";
		obj = new JSONObject(this.execCommand(command_0));
		total_page = obj.getInt("total_count") / 100;
		System.out.println(total_page);
		try {
			for(int k = 1; k < total_page; k++) {
				try {
					String command_1 = "curl -u " + user + ":" + githubAccessToken + " " + endpoint + target + "?q=stars%3A>500&page=" + k +"&per_page=100";			
					obj = new JSONObject(this.execCommand(command_1));
					JSONArray items = obj.getJSONArray("items");
					for( int i = 0; i < 100; i++) {
						System.out.println(items.getJSONObject(i).get("name") + "@@@@@@@@@@@@@");
						String command_2 = "curl -u " + user + ":" + githubAccessToken + " " + items.getJSONObject(i).get("contributors_url") + "?per_page=100";
						JSONArray contributorsArray;
						contributorsArray = new JSONArray(this.execCommand(command_2));
						for(int j = 0; j < contributorsArray.length(); j++) {
							String command_3 = "curl -u " + user + ":" + githubAccessToken + " " + contributorsArray.getJSONObject(j).get("url");
							JSONObject user = new JSONObject(this.execCommand(command_3));
							if(!user.get("name").equals(null)) {
								names.put(user.get("name"));
								System.out.println(user.get("name"));							
							}
						}	
					}
				}catch(JSONException e) {
					@SuppressWarnings("resource")
					Scanner s = new Scanner(System.in);
					System.out.println("Scegli se continuare la ricerca (1/0): ");
					int result = s.nextInt();
					if(result == 1)
						this.changeCredentials();
					else
						return  objToFile;
				}
			}			
		}finally {
			objToFile.put("total_count", names.length());
			objToFile.put("names_list", names);
			FileWriter file = new FileWriter("names.json");
			file.write(objToFile.toString());
			System.out.println("Successfully Copied JSON Object to File...");
			file.close();
		}
		return objToFile;			
	}
	
	public int genderDetector(int start, int stop) throws IOException, JSONException {
		int numOfWomen = 0;
		
		BufferedReader reader = new BufferedReader(new FileReader("../Github_toprepo_explorer/names.json"));
		String inputLine = reader.readLine();
		reader.close();
		JSONObject obj = new JSONObject(inputLine);
		int total_count = obj.getInt("total_count");
		JSONArray names = new JSONArray();
		names = obj.getJSONArray("names_list");	
		for(int j = start; j < stop; j++) {
			String fullName = names.getString(j);
			String firstName;
			try {
				firstName = (String) fullName.subSequence(0, fullName.indexOf(' '));
			}catch(IndexOutOfBoundsException e) {
				firstName = fullName;
			}
			
			
			
			URL url = new URL(genderizeEndpoint  + firstName);
			connection = (HttpURLConnection) url.openConnection();
			if(connection.getResponseCode() == 200) {
				JSONObject genderResponse;
				reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				genderResponse = new JSONObject(reader.readLine());
				if(genderResponse.get("gender").equals("female")) {
					numOfWomen++;
					System.out.println(firstName);
				}
			}
		}
		
		return numOfWomen;
		
	}
	
	private int getRateLimit() throws IOException, JSONException {
		int result = 0;
		String inputLine = "";
		String command = "curl -u " + user + ":" + githubAccessToken + " https://api.github.com/rate_limit";
		Process p;
		p = Runtime.getRuntime().exec(command);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line = reader.readLine();		
		while(line != null) {			
			inputLine += line + "\n";
			line = reader.readLine();
		}		
		p.destroy();
		reader.close();		
		JSONObject obj = new JSONObject(inputLine);
		JSONObject rate = obj.getJSONObject("rate");
		result = rate.getInt("remaining");
		
		return result;
	}
	
	private int changeCredentials(){
		int result = 0;
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Cambia le tue credenziali");
		System.out.print("Nome Utente Github: ");
		this.user = in.nextLine();
		System.out.print("Personal Access Token: ");
		this.githubAccessToken = in.nextLine();
		
		return result;
	}
	
	private String execCommand(String command) throws IOException {
		String result = "";
		String line = "";
		Process p;
		p = Runtime.getRuntime().exec(command);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		line = reader.readLine();		
		while(line != null) {			
			result += line + "\n";
			line = reader.readLine();
		}		
		p.destroy();
		reader.close();
		
		return result;
	}

}
